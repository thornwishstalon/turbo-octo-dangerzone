package test;

import static org.junit.Assert.*;

import org.junit.Test;

import processor.VocabularyBuilder;

public class TEST_PIPED_VocBuilder {

	@Test
	public void test() {
		// fail("Not yet implemented");

		VocabularyBuilder builder = new VocabularyBuilder("");
		builder.buildWithPipe();

	}

}
